import roguelib


def run_game():
    # Call roguelib.load_level() to get a dictionary that represents the running game.
    game = roguelib.load_level('level.txt')

    while True:
        # Draw the game and tell the player how to play it.
        roguelib.clear_screen()
        roguelib.draw_game(game)
        roguelib.print_help_info()

        # Prompt the user for a command.
        user_input = input("> ").strip()

        if user_input in ['q', 'quit']:
            # Quit the game!
            break
        else:
            # Do something else!
            roguelib.process_user_input(game, user_input)


if __name__ == '__main__':
    run_game()
