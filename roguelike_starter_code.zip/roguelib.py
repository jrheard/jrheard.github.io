"""Contains functions useful for building a command-line roguelike game."""
from enum import Enum, auto
import os
import platform
import sys


class Space(Enum):
    """Represents a space in the game level. A space is either empty or a wall."""
    EMPTY = auto()
    WALL = auto()


def move(direction, level, current_player_x, current_player_y):
    """Calculates the player's new position, based on their current position and the direction they'd like to move in.

    Arguments:
        direction - one of ['up', 'right', 'down', 'left']
        level - a 2D list of Spaces
        current_player_x - a number between 0 and ROOM_WIDTH
        current_player_y - a number between 0 and ROOM_HEIGHT

    Returns:
        a list of [new_x, new_y] indicating the player's new position.
        For example: [1, 2]

    Does NOT modify `level`.
    """

    new_x, new_y = current_player_x, current_player_y
    if direction == 'up':
        new_y = current_player_y - 1
    elif direction == 'left':
        new_x = current_player_x - 1
    elif direction == 'down':
        new_y = current_player_y + 1
    elif direction == 'right':
        new_x = current_player_x + 1

    width = len(level)
    height = len(level[0])

    if not (0 <= new_x <= width and 0 <= new_y <= height):
        # The player's somehow attempting to move off of the game world, don't let 'em.
        return current_player_x, current_player_y

    if level[new_x][new_y] == Space.WALL:
        # There's a wall here, the player can't move into this space.
        return current_player_x, current_player_y

    # If we've made it this far, the space that the player is trying to move into is clear!
    return new_x, new_y


def draw_game(game):
    """Draws the game on the screen.
    Walls are represented by '#'s, open space is represented by ' 's, and the player is represented by an '@'.

    When you call this function, it should print something like this to the screen:

    #####
    #   #
    #  @#
    #   #
    #####

    Your level might be a lot bigger than that, it's just an example :)

    Arguments:
        game - a dictionary representing the running game. See the docstring of `load_level()` for more details.
    """
    for y in range(len(game['level'][0])):
        line = ''

        for x in range(len(game['level'])):
            if (x, y) == (game['player']['x'], game['player']['y']):
                # The player's in this space!
                line += '@'

            elif game['level'][x][y] == Space.WALL:
                # It's a wall!
                line += '#'

            elif game['level'][x][y] == Space.EMPTY:
                # There's nothing here!
                line += ' '

            else:
                assert False, "This line of code should never be reached!"

        # We've assembled a line of output, now let's print it!
        print(line)


def make_player(x, y):
    """Returns a dictionary representing the player's character."""
    return {
        'x': x,
        'y': y,
        'health': 100,
    }


def load_level(filename):
    """Parses a level file and returns an initialized game dictionary.

    Arguments:
        filename - a string like 'level.txt'

    Returns:
        A dictionary with fields:
            level - a 2D list of Spaces
            player - a player dictionary (see the docstring of `make_player()` for more details)
    """
    with open(filename) as f:
        lines = f.readlines()

    # Sanity check: make sure all of the lines have the same length.
    first_line_length = len(lines[0])
    for (i, line) in enumerate(lines):
        assert len(line) == first_line_length, "All lines should have the same length, but the first line in the level has length {} and line {} has length {}.".format(first_line_length, i, len(line))

    width = first_line_length
    height = len(lines)

    # Make an empty level whose spaces are indexable by (x, y).
    level = [
        [Space.EMPTY for _ in range(height)]
        for _ in range(width)
    ]

    player = None

    # Find `player` and update `level` with walls.
    for (y, line) in enumerate(lines):
        for (x, char) in enumerate(line[:-1]):

            ####################
            # Hi there students!
            # At this point, we have access to the variables `x`, `y`, and `char`.
            # `x` is a number like 8.
            # `y` is also a number like 3 or whatever.
            # `char` is a string like '@' - it's the character that's in `level.txt` at position (x, y).
            #
            # The point of this loop is to look at `x`, `y`, and `char`
            # for every single space in the `level.txt` file
            # and do something to the game dictionary based on the values of those variables.
            ####################

            if char == ' ':
                # This space is empty, nothing for us to do here.
                pass

            elif char == '#':
                # It's a wall!
                level[x][y] = Space.WALL

            elif char == '@':
                # We found the player's starting position!
                assert player is None, "We found an @ sign at {}, {} but we already found a player at {}!".format(x, y, player)
                player = make_player(x, y)

            else:
                raise Exception("{} contains character {}, but the game doesn't yet know what that character means!".format(filename, char))

    assert player is not None, "We couldn't find a player! Please mark the player's starting position with an @ character somewhere in {}".format(filename)

    # Hi there! This is what a game dictionary looks like!
    return {
        'level': level,
        'player': player,
    }


def clear_screen():
    """Clears the screen."""
    if platform.system() == 'Windows':
        os.system('cls')
    else:
        os.system('clear')


def print_help_info():
    print()
    print('Please enter a command and then press Enter.')
    print()
    print('Available commands:')
    print('[u]p - move up')
    print('[r]ight - move right')
    print('[d]own - move down')
    print('[l]eft - move left')
    print('[q]uit - quit the game')


def process_user_input(game, command):
    """Updates `game` based on `command`.

    Arguments:
        game - a Game.
        command - a string like 'r' or 'down'. See `print_help_info()` for more details.
    """
    move_direction = None
    if command in ['u', 'up']:
        move_direction = 'up'
    elif command in ['r', 'right']:
        move_direction = 'right'
    elif command in ['d', 'down']:
        move_direction = 'down'
    elif command in ['l', 'left']:
        move_direction = 'left'

    if move_direction:
        # The player wants to move their character!
        new_player_x, new_player_y = move(move_direction, game['level'], game['player']['x'], game['player']['y'])
        game['player']['x'] = new_player_x
        game['player']['y'] = new_player_y
